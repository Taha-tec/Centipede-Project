#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include<cmath>

using namespace std;

// Initializing Dimensions.
// resolutionX and resolutionY determine the rendering resolution.
// Don't edit unless required. Use functions on lines 43, 44, 45 for resizing the game window.
const int resolutionX = 960;
const int resolutionY = 960;
const int boxPixelsX = 32;
const int boxPixelsY = 32;
const int gameRows = resolutionX / boxPixelsX; // Total rows on grid
const int gameColumns = resolutionY / boxPixelsY; // Total columns on grid

// Initializing GameGrid.
int gameGrid[gameRows][gameColumns] = {};

// The following exist purely for readability.
const int x = 0;
const int y = 1;
const int exists = 2;


/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Write your functions declarations here. Some have been written for you. //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

//MENU
void showMenu(sf::RenderWindow& window) ;
//player
void drawPlayer(sf::RenderWindow& window, float player[], sf::Sprite& playerSprite);
void movePlayer(float player[]);
//bullet
void moveBullet(float bullet[], sf::Clock& bulletClock);
void drawBullet(sf::RenderWindow& window, float bullet[], sf::Sprite& bulletSprite);
//centipede
void drawCentipede(sf::RenderWindow& window,sf::Sprite& centipedeSprite,float segments[][6],int k,sf::Sprite& headSprite,int head[],int noofseg);
void moveCentipede( sf::Clock& centipedeClock,float segments[12][6],int k,int head[]);
//mushrooms
void drawmush(sf::RenderWindow& window ,sf::Sprite& mushSprite,double mush[][4],int,sf::Sprite&,sf::Sprite&,sf::Sprite&,float[][6],int,int);
//heads
void drawHead(sf::RenderWindow& window,sf::Sprite& headSprite,int k,float extrahead[][6]);
void moveHead(int k,float extrahead[][6]);
//collisions
void CollBulletMush(float bullet[],double mush[][4],float& score,int size,int hit);
void CollBulletSegment(float bullet[],float segments[][6], sf::Sound& kill,int 	head[],int& hit,float& score,double mush[][4],int size,int,int,int );
void CollSegmentMush(double mush[][4],float segments[][6],int size,int hit,int);
void CollMushExtrahead(int size,int hit,double mush[][4],float extrahead[][6]);
void CollSegmentPlayer(float segments[][6],float player[],sf::Sound& death,int);
void CollMushPlayer(int size,int hit,float player[],double mush[][4],sf::Sound& death);
void CollextraheadPlayer(float extrahead[][6],float player[],sf::Sound& death);
//extra creature
void drawSpider(sf::RenderWindow& window,sf::Sprite& spiderSprite,float spider[][5],int);
void moveSpider(float spider[][5],int k,sf::Sound& spidersound);
void CollSpiderMush(float spider[][5],double mush[][4],int size,int hit,int);
void CollSpiderBullet(float spider[][5],float bullet[],float& score,float player[],int);
void CollSpiderPlayer(float spider[][5],float player[],int);
//for levels
void reinitializeSegment(float segments[][6],int head[],int& noofseg,float fastheads[][6],int level);	
void reinitializeMush(double mush[][4],int size,int);
void reinitializeExtraheads(float extrahead[][6]);
void showprogess(sf::RenderWindow& window) ;
void showscore(sf::RenderWindow& window,float);
void movefasthead(float fastheads[][6],int level,int k);
void fasthead(sf::RenderWindow& window,sf::Sprite& headSprite,int k,float fastheads[][6]);
void collfastheadbullet(float fastheads[][6],float bullet[]);
void CollMushFasthead(int size,int hit,double mush[][4],float fastheads[][6]);	

int main()
{
	
	

	// Declaring RenderWindow.
	sf::RenderWindow window(sf::VideoMode(resolutionX, resolutionY), "Centipede", sf::Style::Close | sf::Style::Titlebar);

	// Used to resize your window if it's too big or too small. Use according to your needs.
	window.setSize(sf::Vector2u(640, 640)); // Recommended for 1366x768 (768p) displays.
	//window.setSize(sf::Vector2u(1280, 1280)); // Recommended for 2560x1440 (1440p) displays.
	// window.setSize(sf::Vector2u(1920, 1920)); // Recommended for 3840x2160 (4k) displays.
	
	// Used to position your window on every launch. Use according to your needs.
	window.setPosition(sf::Vector2i(100, 0));

	// Initializing Background Music.
	/*sf::Music bgMusic;
	bgMusic.openFromFile("Music/71bf5203-5c70-4aed-82b0-4cd12d079111.ogg");
	bgMusic.play();
	bgMusic.setVolume(50);*/

	// Initializing Background.
	sf::Texture backgroundTexture;
	sf::Sprite backgroundSprite;
	backgroundTexture.loadFromFile("Textures/alien-planet-landscape-space-game-background_107791-1847.png");
	backgroundSprite.setTexture(backgroundTexture);
	backgroundSprite.setColor(sf::Color(255, 255, 255, 960 * 0.20)); // Reduces Opacity to 25%
	 backgroundSprite.setScale(1.0f, 2.1f);
	
	//for sounds
	 sf::SoundBuffer buffer;
	 buffer.loadFromFile("Sound Effects/fire1.wav");
	 sf::Sound fire;
   	 fire.setBuffer(buffer);
   	 sf::SoundBuffer buffer1;
	 buffer1.loadFromFile("Sound Effects/kill.wav");
	 sf::Sound kill;
   	 kill.setBuffer(buffer1);
   	 sf::SoundBuffer buffer2;
	 buffer2.loadFromFile("Sound Effects/death.wav");
	 sf::Sound death;
   	 death.setBuffer(buffer2);
   	 sf::SoundBuffer buffer3;
	 buffer3.loadFromFile("Sound Effects/spider.wav");
	 sf::Sound spidersound;
   	 spidersound.setBuffer(buffer3);

	// Initializing Player and Player Sprites.
	float player[3] = {};
	player[x] = (gameColumns / 2) * boxPixelsX;
	player[y] = 900;//(gameColumns * 3 / 4) * boxPixelsY;
	player[exists]=true;
	sf::Texture playerTexture;
	sf::Sprite playerSprite;
	playerTexture.loadFromFile("Textures/player.png");
	playerSprite.setTexture(playerTexture);
	playerSprite.setTextureRect(sf::IntRect(0, 0, boxPixelsX, boxPixelsY));

	// Initializing Bullet and Bullet Sprites.
	float bullet[3] = {};
	bullet[x] = player[x];
	bullet[y] = player[y] - boxPixelsY+60;
	bullet[exists] = false;
	sf::Clock bulletClock;
	sf::Texture bulletTexture;
	sf::Sprite bulletSprite;
	bulletTexture.loadFromFile("Textures/bullet.png");
	bulletSprite.setTexture(bulletTexture);
	bulletSprite.setTextureRect(sf::IntRect(0, 0, 20, 20));
	//Initialzing segments sprites
	
	sf::Clock centipedeClock;
	sf::Texture centipedeTexture;
	sf::Sprite centipedeSprite;
	centipedeTexture.loadFromFile("Textures/c_body_left_walk.png");
	centipedeSprite.setTexture(centipedeTexture);
	centipedeSprite.setTextureRect(sf::IntRect(0,0 ,27.5, 32));
	
	//initializing head sprites
	sf::Texture headTexture;
	sf::Sprite headSprite;
	headTexture.loadFromFile("Textures/c_head_left_walk.png");
	headSprite.setTexture(headTexture);
	headSprite.setTextureRect(sf::IntRect(0,0 ,28, 32));
	//initializng mushroom sprites
	sf::Texture mushTexture;
	sf::Sprite mushSprite;
	mushTexture.loadFromFile("Textures/mushroom.png");
	mushSprite.setTexture(mushTexture);
	mushSprite.setTextureRect(sf::IntRect(0,30,30, 32));	//it is poisonous mushroom
	sf::Texture mush1Texture;
	sf::Sprite mush1Sprite;
	mush1Texture.loadFromFile("Textures/mushroom.png");
	mush1Sprite.setTexture(mush1Texture);
	mush1Sprite.setTextureRect(sf::IntRect(30,30,30, 32));
	sf::Texture mush2Texture;
	sf::Sprite mush2Sprite;
	mush2Texture.loadFromFile("Textures/mushroom.png");
	mush2Sprite.setTexture(mush2Texture);
	mush2Sprite.setTextureRect(sf::IntRect(0,0,30, 32));
	sf::Texture mush3Texture;
	sf::Sprite mush3Sprite;
	mush3Texture.loadFromFile("Textures/mushroom.png");
	mush3Sprite.setTexture(mush3Texture);
	mush3Sprite.setTextureRect(sf::IntRect(30,0,30, 32));
	//making text for score
	sf::Font font;
	font.loadFromFile("RussoOne-Regular.ttf");
	sf::Text scoreText;
	scoreText.setFont(font);
	scoreText.setCharacterSize(30);
	scoreText.setFillColor(sf::Color::Yellow);
	scoreText.setPosition(700, 920); 
	//extra creature sprite
	sf::Texture spiderTexture;
	sf::Sprite spiderSprite;
	spiderTexture.loadFromFile("Textures/spider_and_score.png");
	spiderSprite.setTexture(spiderTexture);
	spiderSprite.setTextureRect(sf::IntRect(0, 0, 60, 32));
	
	int i;
	int j;
	int k=0;	
			
	srand(time(0));
	int noofseg=12;			//To keep track of total no of segments
	float score=0.0;		//to keep track of score
	int level=1;				//to keep track of level
	const int exist=4;		//to check the fourth column of arrays
	int hit=0;			//to check how many hits are given to segments

	float random=rand()%950+10;	//For random values of x-axis of segments
	float segments[noofseg][6]={		//initialization of segments
	{0,random,-357.5+11*27.5,true,true,0},
        {1, random, -357.5+10*27.5,true,true,0},
        {2, random, -357.5+9*27.5,true,true,0},
        {3, random, -357.5+8*27.5,true,true,0},
        {4, random, -357.5+7*27.5,true,true,0},
        {5, random,  -357.5+6*27.5,true,true,0},
        {6, random, -357.5+5*27.5,true,true,0},
        {7, random, -357.5+4*27.5,true,true,0},
        {8, random, -357.5+3*27.5,true,true,0},
        {9, random, -357.5+2*27.5,true,true,0},
        {10, random,-357.5+1*27.5,true,true,0},
        {11, random, -357.5+0*27.5,true,true,0},
         };
         
        //following is array of heads to keep track of index where head occurs of segment 
    	int head[12]={0,noofseg,noofseg,noofseg,noofseg,noofseg,noofseg,noofseg,noofseg,noofseg,noofseg,noofseg};
    	int size=rand()%11+20;		//it is used for size of mushrooms
        double mush[size+60][4];		//mushroom total size is size +60
 		
        for(int i=0;i<size;i++)		//first all backgorund mushrooms are intitialized
             {
             	
             		mush[i][0]=fmod(rand(), 760.0) + 30.0;
             		mush[i][1]=fmod(rand(), 760.0) + 1.0;
             		mush[i][2]=true;
             		mush[i][3]=0;
             		while(fmod(mush[i][1],30)!=0)
             			mush[i][1]=fmod(rand(), 760.0) + 1.0;
             }	
             	
     	     for(int i=size;i<size+noofseg;i++)		//then mushromms that come in place of segments are intitialized with some garbage value.
     	     {
     	     		mush[i][x]=-100;
     	     		mush[i][y]=-100;
     	     		mush[i][3]=0;
     	     }		
     	     			
    		
    	float extrahead[4][6]={			//this array for extra heads that come at palyer area
    	{0,940,810,false,true,4},
        {1,940, 810, false,true,4},
        {2,940, 810, false,true,4},
        {3,940, 810, false,true,4},
         };
    	
    	float spider[4][5]={{960,660,false,true,0},	//this array is for spiders 
    			    {960,660,false,true,0},
    			    {960,660,false,true,0},
    			    {960,660,false,true,0}};	
  	float fastheads[12][6];		
  	
  	   for(int i=0;i<12;i++)		//this array is for fast heads that come after first level
  	{
  			fastheads[i][0]=i;
         		fastheads[i][1]=960-(11-i)*27.5;
         		fastheads[i][2]=0;
         		fastheads[i][3]=false;
         		fastheads[i][4]=true;
         		fastheads[i][5]=0;
         }					    	
    			    
    			    
    	//showing menu
      	showMenu( window) ;
      	
	while(window.isOpen()) {

		///////////////////////////////////////////////////////////////
		//                                                           //
		// Call Your Functions Here. Some have been written for you. //
		// Be vary of the order you call them, SFML draws in order.  //
		//                                                           //
		///////////////////////////////////////////////////////////////
		int seg=0;    //variable to know the number of segment
		//drawing backgorund
		window.draw(backgroundSprite);
		
		if(player[exists]==true)
		{		//if player will exist it is drawn and moved
			drawPlayer(window, player, playerSprite);
			movePlayer( player);	
		}							

		for(int k=0;k<size+hit;k++)					//it draws all the mushrooms
		{
			if((mush[k][exists+1]<2))
			{

				drawmush(window, mushSprite,mush,k,mush1Sprite,mush2Sprite,mush3Sprite,segments,seg,size);
				
			}
			
			else
			{
				mush[k][x]=-100000;
			}
			
					
		}
		CollBulletMush(bullet,mush,score,size,hit);			// it check the collsion between bullet and mushroom		
		
		
		for(;seg<noofseg;seg++)
		{						//this loop draws and moves the centipede segment one by one
			if((segments[seg][exist]==true))
			{
				
				drawCentipede(window, centipedeSprite,segments,seg,headSprite,head,noofseg);
				moveCentipede(centipedeClock,segments,seg,head);	
		
				
			}
		}	
		
		//This function is used to check collision b/w bullet and each segment									
		CollBulletSegment(bullet,segments,kill,head,hit,score,mush,size,exist,noofseg,level);		
		
		//This function is used to check collision b/w mushroom and each segment									
		CollSegmentMush(mush,segments,size,hit,noofseg);
		
		//this loop is used to permit the extra heads tht come in player area
	
		for(int i=0;i<noofseg;i++)
		{
			
				if(segments[i][5]==31)			//if segments row matches certain number than extrahead is permitted
				{
					extrahead[0][exists+1]=true;
				}
				
				if(segments[i][5]==36)
				{
					extrahead[1][exists+1]=true;
				}
				
				if(segments[i][5]==41)
				{
					extrahead[2][exists+1]=true;
				}
				
				if(segments[i][5]==46)
				{
					extrahead[3][exists+1]=true;
				}
				
		}	
		
		//This is used to draw and move the extraheads
		for(int k=0;k<4;k++)
		{		
			if((extrahead[k][exists+1]==true)&&(extrahead[k][exist]==true))
			{
				
				drawHead(window, headSprite,k,extrahead);
				moveHead(k,extrahead);	
		
				
			}
		}
		
		//this fucntion is used to check the collision of extra heads and mushroom
		CollMushExtrahead(size,hit,mush,extrahead);
		
		//This loop is used to check collision b/w bullet and extrahead.
		for(int k=0;k<4;k++)
		{		
			if((abs(bullet[x]-extrahead[k][x+1])<13.75)&&(abs(bullet[y]-extrahead[k][y+1])<13.75)&&bullet[exists]==true)	
			{
				extrahead[k][exist]=false;
			}
		}		
		
		//This fucntion draws and moves bullet if it exists	
		if (bullet[exists] == true){
			moveBullet(bullet, bulletClock);
			drawBullet(window, bullet, bulletSprite);
		}
		
		//Thesse fucntions check collision b/w segment,player and mushroom,player and extraheads,player.
		CollSegmentPlayer(segments,player,death,noofseg);
	
		CollMushPlayer(size,hit,player,mush,death);	
	
		CollextraheadPlayer(extrahead,player,death);
					
		
		
		//these conditions revive the bullet
		if(bullet[exists]==false)
		{
			bullet[x] = player[x];
			bullet[y] = player[y] - boxPixelsY+60;
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Space	))
			{
				bullet[exists]=true;
				fire.play();
			}	
		}
		
		//These conditions permit the spiders. if segment passes ccertain row then spider comes
		for(int i=0;i<noofseg;i++)
		{
			
				if(segments[i][5]==10)			//if segments row matches certain number than extrahead is permitted
				{
					spider[0][exists]=true;
				}
				
				if(segments[i][5]==13)
				{
					spider[1][exists]=true;
				}
				
				if(segments[i][5]==16)
				{
					spider[2][exists]=true;
				}
				
				if(segments[i][5]==20)
				{
					spider[3][exists]=true;
				}
				
		}	
		
	
		
		//this loop and fucntions are used to draw,move and check collisions of spiders
		for(int k=0;k<4;k++)
		{	
			if(spider[k][exists]==true&&spider[k][exists+1]==true)
			{	
				drawSpider(window,spiderSprite,spider,k);
				moveSpider(spider,k,spidersound);
				CollSpiderMush(spider,mush,size,hit,k);
				CollSpiderBullet(spider,bullet,score,player,k);
				CollSpiderPlayer(spider,player,k);

			}
		}
		for(int k=0;k<12;k++)
		{
			if(fastheads[k][exists+1]==true&&fastheads[k][exist]==true)
			{
				fasthead(window,headSprite,k,fastheads);
				movefasthead(fastheads,level,k);
				collfastheadbullet(fastheads,bullet);
				 CollMushFasthead( size, hit,mush, fastheads);	
			}
		}				
		
	
		sf::Event e;
		while (window.pollEvent(e)) {
			if (e.type == sf::Event::Closed) {
				return 0;
			}
		}
		
		int check=0;	//this variable is used to check whether all segments are dead
		for(int k=0;k<noofseg;k++)
		{
			if(segments[k][exist]==false)
				check++;
			
			
		}
		
		//if all segments are dead then for next level all arrays are reinitialized
		if(check==noofseg)
		{
			hit=0;
			reinitializeSegment(segments,head,noofseg,fastheads,level);
			reinitializeMush(mush,size,noofseg);
			reinitializeExtraheads(extrahead);
			
			level++;
			showprogess(window);
			
			if(level%4+1==2)					//This is used to change colour of head sprite after every level
				headSprite.setColor(sf::Color::Red);
			else if	(level%4+1==3)
				headSprite.setColor(sf::Color::Blue);
			else if	(level%4+1==4)	
				headSprite.setColor(sf::Color::White);			
		}	
		
		if(player[exists]==false)
				showscore(window,score);		//If player is dead then fincal score is shown
		
		
		scoreText.setString("Score: " + std::to_string(score));		// this is used to show score at bottom	
		window.display();
		window.clear();
		window.draw(scoreText);
	}
}

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// Write your functions definitions here. Some have been written for you. //
//                                                                        //
////////////////////////////////////////////////////////////////////////////

void drawPlayer(sf::RenderWindow& window, float player[], sf::Sprite& playerSprite) {	//used to draw player
	playerSprite.setPosition(player[x], player[y]);
	window.draw(playerSprite);
}
void drawmush(sf::RenderWindow& window ,sf::Sprite& mushSprite,double mush[][4],int k,sf::Sprite& mush1Sprite,sf::Sprite& mush2Sprite,sf::Sprite& mush3Sprite,float segments[][6],int seg,int size)	
								//used to draw mushrooms and it will check whteher to draw poisionous mushroom
{								// or simple mushroom	
	if(segments[seg][5]>25&&k>=size&&mush[k][y]>=780)
	{
		if(mush[k][exists+1]>1&&mush[k][exists+1]<3)
		{	
			mush1Sprite.setPosition(mush[k][x], mush[k][y]);
			window.draw(mush1Sprite);
			
		}
		else
		{
			mushSprite.setPosition(mush[k][x], mush[k][y]);
			window.draw(mushSprite);
			
		}
	}
	else
	{		
			
		if(mush[k][exists+1]>0&&mush[k][exists+1]<3)
		{	
			mush3Sprite.setPosition(mush[k][x], mush[k][y]);
			window.draw(mush3Sprite);
		}
		
		else 
		{	
			mush2Sprite.setPosition(mush[k][x], mush[k][y]);
			window.draw(mush2Sprite);
		}
	}	
		
	
}	
void moveBullet(float bullet[], sf::Clock& bulletClock) {	//It is used to move bullet and check whther it passsed the limit
	
	if (bulletClock.getElapsedTime().asMilliseconds() < 20)
		return;

	bulletClock.restart();
	bullet[y] -= 30;	
	if (bullet[y] < -32)
		bullet[exists]=false;
		
		
}
void drawBullet(sf::RenderWindow& window, float bullet[], sf::Sprite& bulletSprite) {	//used to draw bullet
	bulletSprite.setPosition(bullet[x], bullet[y]);
	window.draw(bulletSprite);
}
void movePlayer(float player[])		//used to move player thorugh keyboard keys and check whether player don't cross player area.
{	
	
		if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left))
		{
			
				player[x]=player[x]-0.3;
			
					
		}
		else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right))
		{
			
			
			
				player[x]=player[x]+0.3;	
		}
		else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Down))
		{
			
			
				player[y]=player[y]+0.3;
		}
		else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up))
		{
			
			
				player[y]=player[y]-0.3;	
		}
		
		if(player[y]<780)
			player[y]=930;
		else if(player[y]>930)
			player[y]=780;
		else if(player[x]<0)
			player[x]=960;
		else if(player[x]>960)
			player[x]=0;			
}
void drawCentipede(sf::RenderWindow& window,sf::Sprite& centipedeSprite,float segments[][6],int k,sf::Sprite& headSprite,int head[],int noofseg)
{							// it will draw centipede and check the presence of head and draw it
		for(int i=0;i<noofseg;i++)
		{	
			if(head[i]==k)
			{
				headSprite.setPosition(segments[k][x+1], segments[k][y+1]);
				window.draw(headSprite);
				return ;
			}	
		}	
	
		centipedeSprite.setPosition(segments[k][x+1], segments[k][y+1]);
		window.draw(centipedeSprite);
			
		
}	
void moveCentipede( sf::Clock& centipedeClock,float segments[12][6],int k,int head[])	// it will move centipede segments one by one
{	
			//first it will check whther segment comes in layer area or not
		
			//Then it will check the rows of segment and resultantly move the segment
	
			if(segments[k][y+1]<0)
			{	
				segments[k][y+1]+=0.1;
				return;
			}	 
				
		
		
			if(fmod(segments[k][5],2)!=0)
			{
							
								segments[k][x+1]+=0.11;
						
						
			}			
			else
			{
								segments[k][x+1]-=0.11;
						
			}
			if(segments[k][5]<30)
			{
						if (segments[k][x+1] < 0||segments[k][x+1]>960)
						{
							segments[k][y+1]+=30;
							segments[k][5]++;
						}
			}
			else						//It is used to check whether segment comes at bottom of player area
			{						//then it will move upward the segment based on number of row
				if(fmod(segments[k][5],10)<=4.0&&fmod(segments[k][5],10)>=0.0)
				{
						if (segments[k][x+1] < 0||segments[k][x+1]>960)
						{
							segments[k][y+1]-=30;
							segments[k][5]++;
						}
				}
				else
				{
						if (segments[k][x+1] < 0||segments[k][x+1]>960)
						{
							segments[k][y+1]+=30;
							segments[k][5]++;
						}
				}
					
					
			}			
						
					
										
		
}	
void drawHead(sf::RenderWindow& window,sf::Sprite& headSprite,int k,float extrahead[][6])	//used to draw extraheads
{	
	headSprite.setPosition(extrahead[k][x+1], extrahead[k][y+1]);
				window.draw(headSprite);
}			
				
				
				
void moveHead(int k,float extrahead[][6])		//used to move extra heads based on their row number.
{
	
	if(fmod(extrahead[k][5],2)!=0)
	{
		extrahead[k][x+1]+=0.21;
					
					
	}			
	else
	{
		extrahead[k][x+1]-=0.21;
					
	}
		
		
		
	if(fmod(extrahead[k][5],10)<=4.0&&fmod(extrahead[k][5],10)>=0.0)
			{
						if (extrahead[k][x+1] < 0||extrahead[k][x+1]>960)
						{
							extrahead[k][y+1]-=30;
							extrahead[k][5]++;
						}
			}
	else
			{
						if (extrahead[k][x+1] < 0||extrahead[k][x+1]>960)
						{
							extrahead[k][y+1]+=30;
							extrahead[k][5]++;
						}
			}
				
}


//collisions
void CollBulletMush(float bullet[],double mush[][4],float& score,int size,int hit)	
{
		for(int k=0;k<size+hit;k++)			//checking collision of bullet and mush
		{
			if((abs(bullet[x]-mush[k][x])<16)&&(abs(bullet[y]-mush[k][y])<16))
			{
				mush[k][exists+1]++;
				bullet[exists]=false;
				score+=0.5;
				
				
			}
		}		
}

void CollBulletSegment(float bullet[],float segments[][6], sf::Sound& kill,int head[],int& hit,float& score,double mush[][4],int size,int exist,int noofseg,int level)
{
	for(int k=0;k<noofseg;k++)		//checking collision of bullet and segment
		{	
			if((abs(bullet[x]-segments[k][x+1])<13.75)&&(abs(bullet[y]-segments[k][y+1])<13.75)&&bullet[exists]==true)
			{
				kill.play();
				for(int a=0;a<hit+1;a++)		//if the head collides with bullet then total 20 score is added
				{
					if(head[a]==k)
					{		
						
						score+=10;		
						
					}
				}	
				if(level==1)
				{				//in first level if head collides then whole segments vanish
					if(head[0]==k)			
					{
						for(int l=head[0];l<noofseg;l++)
								{
									segments[l][exist]=false;	
									segments[l][x+1]=-1000;
									segments[l][y+1]=-1000;
									
								}
					}
				}					

						
				
				score+=10;
				segments[k][exist]=false;
				hit++;
				mush[size-1+hit][x]=segments[k][x+1];
				mush[size-1+hit][y]=segments[k][y+1];
				segments[k][x+1]=-10000000;
				segments[k][y+1]=-10000000;
				bullet[exists]=false;
				head[hit]=k+1;			//the head will appear next to shooted segment.
				
				
			}
		}
}
void CollSegmentMush(double mush[][4],float segments[][6],int size,int hit,int noofseg)
{
		for(int l=0;l<size+hit;l++)				//To check the collission of segment and mush
		{
			for(int k=0;k<noofseg;k++)
			{
				
						if((abs(mush[l][x]-segments[k][x+1])<15)&&(abs(mush[l][y]-segments[k][y+1])<15))
						{
							if(segments[k][5]<30)
							{
								segments[k][y+1]+=30;
								
								segments[k][5]++;
							}
							else
							{
								if(fmod(segments[k][5],10)<=4.0&&fmod(segments[k][5],10)>=0.0)
								{
						
									segments[k][y+1]-=30;
									segments[k][5]++;
								}
								else
								{
									segments[k][y+1]+=30;
								
									segments[k][5]++;
								}	
									
							}		
								
							
						}
			}			
									
					
		}
							
}
void CollMushExtrahead(int size,int hit,double mush[][4],float extrahead[][6])	//check collision of mushroom and extraa heads and move it
{										//vertically based on row number of segment
	for(int l=size;l<size+hit;l++)			
		{	
			for(int k=0;k<4;k++)
				{
					
							if((abs(mush[l][x]-extrahead[k][x+1])<30)&&(abs(mush[l][y]-extrahead[k][y+1])<15))
							{
								
									if(fmod(extrahead[k][5],10)<=4.0&&fmod(extrahead[k][5],10)>=0.0)
									{
							
										extrahead[k][y+1]-=30;
										extrahead[k][5]++;
									}
									else
									{
										extrahead[k][y+1]+=30;
									
										extrahead[k][5]++;
									}	
										
										
									
								
							}
				}
		}			
	
}
void CollSegmentPlayer(float segments[][6],float player[],sf::Sound& death,int noofseg)	//check collsion of segments and players. 
{											// if segment colliddes then player vanish
		for(int k=0;k<noofseg;k++)
			{
				
						if((abs(segments[k][x+1]-player[x])<30)&&(abs(segments[k][y+1]-player[y])<16))
						{
							player[exists]=false;
							player[x]=-1000;
						
						}
			}
		
}
void CollMushPlayer(int size,int hit,float player[],double mush[][4],sf::Sound& death)	//checking collsion of posionous mushromm and player
{	
		for(int l=size;l<size+hit;l++)
			{
				if(abs(player[x]-mush[l][x])<30&&(abs(player[y]-mush[l][y])<16))
				{
					player[exists]=false;
					player[x]=-1000;
					death.play();
				}
			}	
}
void CollextraheadPlayer(float extrahead[][6],float player[],sf::Sound& death)	//check collision of extra heads and playeer
{
		for(int k=0;k<4;k++)
			{
				
				if((abs(extrahead[k][x+1]-player[x])<30)&&(abs(extrahead[k][y+1]-player[y])<16)&&((extrahead[k][exists+1])==true))
						{
							player[exists]=false;
							player[y]=100000;
						
						}
			}
}



//creatures
void drawSpider(sf::RenderWindow& window,sf::Sprite& spiderSprite,float spider[][5],int k)	//used to draw spiders
{
		spiderSprite.setPosition(spider[k][x],spider[k][y]);
				window.draw(spiderSprite);
}
void moveSpider(float spider[][5],int k,sf::Sound& spidersound)		//used to move spiders zig zag based on their row number
{
		spider[k][x]-=0.1;
		if(fmod(spider[k][4],2)==0)
			spider[k][y]+=0.1;
		else
			spider[k][y]-=0.1;
			
			
		if(spider[k][y]>960||spider[k][y]<660)
		{
			spidersound.play();
			spider[k][4]++;
		}
		if(spider[k][x]<0)
			spider[k][exists]=false;
}
void CollSpiderMush(float spider[][5],double mush[][4],int size,int hit,int k)	//used to check collison of spider and mushroom. SPIDER eats mush
{
	for(int l=0;l<size+hit;l++)
			{
				if(abs(spider[k][x]-mush[l][x])<30&&(abs(spider[k][y]-mush[l][y])<16))
				{
					mush[l][exists+1]=2;
				}
			}
}			
void CollSpiderBullet(float spider[][5],float bullet[],float& score,float player[],int k)	
{
			//Chekcing colllisioon of spider and bullet
		
			if((abs(bullet[x]-spider[k][x])<30)&&(abs(bullet[y]-spider[k][y])<16)&&(bullet[exists]==true))
			{
					spider[k][3]=false;
					bullet[exists]=false;
					if(spider[k][x]-player[x]<30&&player[y]-spider[k][y]<60)//if spider is one step from player then 900 add
					{
						score+=900;

					}
					else if(spider[k][x]-player[x]<30&&player[y]-spider[k][y]<120)
					{
						score+=600;			//if it is two step then 600 add

					}
					else if(spider[k][x]-player[x]<30&&player[y]-spider[k][y]<300)
					{
						score+=300;			//if it is more than two step than 300 add.
					}
				
    							
				
				
			}
			
		
		
}		
void CollSpiderPlayer(float spider[][5],float player[],int k)	//cehcking colllsion fo spider and players
{
	if(abs(player[x]-spider[k][x])<15&&(abs(player[y]-spider[k][y])<32))
				{
					player[exists]=false;
					player[x]=-1000;
					
				}
}


//FOR LEVELS

void reinitializeSegment(float segments[][6],int head[],int& noofseg,float fastheads[][6],int level)	//after levels end segments and head array reinitialzed
{
	
	noofseg--;		//when new level starts no of segment decrease
	head[0]=0;
		for(int k=1;k<12;k++)
		{
			head[k]=noofseg;		//heads are intitlazed 
		}	
	srand(time(0));
	float random=rand()%950+10;

         for(int i=0;i<noofseg;i++)
         {
         		segments[i][0]=i;
         		segments[i][1]=	random;
         		segments[i][2]=-357.5+(11-i)*27.5;
         		segments[i][3]=true;
         		segments[i][4]=true;
         		segments[i][5]=0;
         }
         for(int i=0;i<level;i++)		//fast heads are activateed
        {
        	fastheads[i][exists+1]=true;
        }

     	
         	
}    
void reinitializeMush(double mush[][4],int size,int noofseg){	//mushromm restart
	size+=(0.2*(float)size)+(float)size;
	
	     for(int i=0;i<size;i++)
             {
             	
             		mush[i][0]=fmod(rand(), 760.0) + 30.0;
             		mush[i][1]=fmod(rand(), 780.0) + 1.0;
             		mush[i][2]=true;
             		mush[i][3]=0;
             		while(fmod(mush[i][1],30)!=0)
             			mush[i][1]=fmod(rand(), 780.0) + 1.0;
             }
          	
             	
     	     for(int i=size;i<size+noofseg;i++)
     	     {
     	     		mush[i][x]=-100;

     	     		mush[i][y]=-100;
     	     		mush[i][3]=0;
     	     }
}     	         		

void reinitializeExtraheads(float extrahead[][6])		//extra heads restart	
{
			
    
	for(int i=0;i<4;i++)
	{
			extrahead[i][0]=i;
         		extrahead[i][1]=970;
         		extrahead[i][2]=810;
         		extrahead[i][3]=false;
         		extrahead[i][4]=true;
         		extrahead[i][5]=4;
         }		
	 
} 
void fasthead(sf::RenderWindow& window,sf::Sprite& headSprite,int k,float fastheads[][6])
{
		 //used to draw fastheads
		 headSprite.setPosition(fastheads[k][x+1], fastheads[k][y+1]);
				window.draw(headSprite);
}				
		 
void movefasthead(float fastheads[][6],int level,int k)	//it is used to move fast heads
{
	 
	if(fmod(fastheads[k][5],2)!=0)
	{
		fastheads[k][x+1]+=0.21;
					
					
	}			
	else
	{
		fastheads[k][x+1]-=0.21;
					
	}
		
		if(fastheads[k][5]<30)
			{
						if (fastheads[k][x+1] < 0||fastheads[k][x+1]>960)
						{
							fastheads[k][y+1]+=30;
							fastheads[k][5]++;
						}
			}
			else						//It is used to check whether segment comes at bottom of player area
			{
		
						if(fmod(fastheads[k][5],10)<=4.0&&fmod(fastheads[k][5],10)>=0.0)
							{
									if (fastheads[k][x+1] < 0||fastheads[k][x+1]>960)
									{
										fastheads[k][y+1]-=30;
										fastheads[k][5]++;
									}
							}
						else
							{
									if (fastheads[k][x+1] < 0||fastheads[k][x+1]>960)
									{
										fastheads[k][y+1]+=30;
										fastheads[k][5]++;
									}
							}
			}				
}
void CollMushFasthead(int size,int hit,double mush[][4],float fastheads[][6])	//check collision of mushroom and fast heads and move it
{										//vertically based on row number of fast heads
	for(int l=0;l<size+hit;l++)			
		{	
			for(int k=0;k<12;k++)
				{
					
							if((abs(mush[l][x]-fastheads[k][x+1])<15)&&(abs(mush[l][y]-fastheads[k][y+1])<15))

							{
								
								if(fastheads[k][5]<30)
									{
											fastheads[k][y+1]+=30;
										
											fastheads[k][5]++;
									}
								else
								{
									if(fmod(fastheads[k][5],10)<=4.0&&fmod(fastheads[k][5],10)>=0.0)
									{
							
										fastheads[k][y+1]-=30;
										fastheads[k][5]++;
									}
									else
									{
										fastheads[k][y+1]+=30;
									
										fastheads[k][5]++;
									}
								}		
										
										
									
								
							}
				}
		}			
	
}
void collfastheadbullet(float fastheads[][6],float bullet[])	//cheking of bullet and fast heads collision
{
	for(int k=0;k<12;k++)
		{		
			if((abs(bullet[x]-fastheads[k][x+1])<13.75)&&(abs(bullet[y]-fastheads[k][y+1])<13.75))	
			{
				fastheads[k][4]=false;
			}
		}
}							



// FOR MENUS


void showMenu(sf::RenderWindow& window) {		// it will show the menu
	while(window.isOpen())
	{
		sf::Texture backgroundTexture;
		sf::Sprite backgroundSprite;
		backgroundTexture.loadFromFile("Textures/background.png");
		backgroundSprite.setTexture(backgroundTexture);
		backgroundSprite.setColor(sf::Color(255, 255, 255, 255 * 0.20));
		

	    sf::Font font;
	    font.loadFromFile("RussoOne-Regular.ttf");

	    sf::Text title;
	    title.setFont(font);
	    title.setCharacterSize(45);
	    title.setFillColor(sf::Color::Blue);
	    title.setString("WELCOME TO CENTIPEDE GAME");
	    title.setPosition(resolutionX / 2 -300 , resolutionY / 4);

	    sf::Text startText;
	    startText.setFont(font);
	    startText.setCharacterSize(30);
	    startText.setFillColor(sf::Color::White);
	    startText.setString("Press Enter to Start");
	    startText.setPosition(resolutionX / 2 - 150, resolutionY / 3);



	    window.clear();
	    window.draw(backgroundSprite);

	    window.draw(title);
	    window.draw(startText);
	   
	    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Return))
	    	break;
	    	
			sf::Event e;
			while (window.pollEvent(e)) {
				if (e.type == sf::Event::Closed) {
					return ;
				}
			}
	    

	    window.display();
	} 
} 
void showprogess(sf::RenderWindow& window) {		//it will show the completion of level sign
	while(window.isOpen())
	{
		sf::Texture backgroundTexture;
		sf::Sprite backgroundSprite;
		backgroundTexture.loadFromFile("Textures/background.png");
		backgroundSprite.setTexture(backgroundTexture);
		backgroundSprite.setColor(sf::Color(255, 255, 255, 255 * 0.20));
		

	    sf::Font font;
	    font.loadFromFile("RussoOne-Regular.ttf");

	    sf::Text title;
	    title.setFont(font);
	    title.setCharacterSize(45);
	    title.setFillColor(sf::Color::Blue);
	    title.setString("LEVEL COMPLETED");
	    title.setPosition(resolutionX / 2 -300 , resolutionY / 4);

	    sf::Text startText;
	    startText.setFont(font);
	    startText.setCharacterSize(30);
	    startText.setFillColor(sf::Color::White);
	    startText.setString("Press Enter to continue");
	    startText.setPosition(resolutionX / 2 - 150, resolutionY / 3);



	    window.clear();
	    window.draw(backgroundSprite);

	    window.draw(title);
	    window.draw(startText);
	   
	    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Return))
	    	break;
	    	
		sf::Event e;
		while (window.pollEvent(e)) {
			if (e.type == sf::Event::Closed) {
				return ;
			}
		}
	    

	    window.display();
	} 
}  
void showscore(sf::RenderWindow& window,float score) {		//it will show the final score
	while(window.isOpen())
	{
		sf::Texture backgroundTexture;
		sf::Sprite backgroundSprite;
		backgroundTexture.loadFromFile("Textures/background.png");
		backgroundSprite.setTexture(backgroundTexture);
		backgroundSprite.setColor(sf::Color(255, 255, 255, 255 * 0.20));
		

	    sf::Font font;
	    font.loadFromFile("RussoOne-Regular.ttf");

	    sf::Text title;
	    title.setFont(font);
	    title.setCharacterSize(45);
	    title.setFillColor(sf::Color::Blue);
	    title.setString("GAME OVER");
	    title.setPosition(resolutionX / 2 -300 , resolutionY / 4);

	    sf::Text startText;
	    startText.setFont(font);
	    startText.setCharacterSize(30);
	    startText.setFillColor(sf::Color::White);
		startText.setString("Score: " + std::to_string(score));		
	    startText.setPosition(resolutionX / 2 - 150, resolutionY / 3);



	    window.clear();
	    window.draw(backgroundSprite);

	    window.draw(title);
	    window.draw(startText);
	   
	    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Return))
	    {
	    	window.close();
	    	break;
	    }	
	    
		sf::Event e;
		while (window.pollEvent(e)) {
			if (e.type == sf::Event::Closed) {
				return ;
			}
		}
	    

	    window.display();
	} 
}  
    
         				
					
										






